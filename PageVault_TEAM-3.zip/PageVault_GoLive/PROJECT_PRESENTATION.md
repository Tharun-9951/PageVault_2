# PageVault Go Live Edition — Project Overview

## Goal
A college library website that gives students a simple place to discover books, browse department catalogues, and manage demo borrowing.

## Tech stack
- HTML5: page structure and forms
- CSS3: responsive styling and layout
- JavaScript: login demo, catalogue rendering, filtering, borrowing/return, page navigation
- JSON: branch catalogue data
- localStorage: demo session and borrow state
- Open Library Search API: online external catalogue search

## Features
1. Demo college-email login with password visibility option.
2. 13 branch catalogue sections.
3. Search by title, author and branch.
4. Availability filter and branch filter.
5. Borrow books for 14 days.
6. Maximum three active loans per student.
7. My Bookshelf and return actions.
8. Smart Match suggestions for the logged-in student's branch.
9. Open Library online search.
10. Responsive layout with sidebar navigation.

## Flow
Student signs in using a demo account → dashboard → catalogue or Smart Match → borrows a title → loan appears on My Bookshelf → student returns it.

## Important limitation
This Go Live edition is a static front-end demo. Browser localStorage is not secure, and the browser cannot provide server-side transaction guarantees. The Express/SQLite edition should be used if real accounts, robust security or real multi-user borrowing is required.
