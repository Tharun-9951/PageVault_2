# PageVault — Go Live Edition

This version is designed to run directly in VS Code using the **Live Server / Go Live** button. It uses HTML, CSS, JavaScript and browser `localStorage` (no Node.js, no npm install, no terminal command).

## Start
1. Extract this ZIP.
2. Open the **PageVault_GoLive** folder in VS Code (not just the HTML file).
3. Ensure the **Live Server** extension is installed.
4. Open `index.html` and click **Go Live** in the bottom-right corner.
5. Live Server opens the site in your browser. `.vscode/settings.json` sets port 5500 and requests Chrome as browser.

## Demo login
- `MRTC26MVCSMR0303@gmail.com` / `MRTC@123` (AIML demo account)

## Features
- College demo sign-in with show-password control
- 13-branch book catalogue (data loaded from `data-books.json`)
- Search books by title, author, branch; branch and availability filters
- Borrow / return books, 14-day due dates and three active-loan limit
- Overdue status computed from due dates
- My Bookshelf, branch-based Smart Match, Open Library online search
- Responsive sidebar and desktop/mobile layout

## Important demo limitation
Since Go Live serves static files only, this edition stores demo login state and loan records in the browser's localStorage. This is **not real secure authentication**; users can inspect or alter browser data. Passwords are demo credentials only. Do not enter real student passwords or personal information. The SQLite / Express backend edition is required for genuine server-side authentication and transactions.

## Troubleshooting
- If clicking Go Live does not open a browser, right-click `index.html` and choose **Open with Live Server**. You can also open `http://127.0.0.1:5500` manually after starting Live Server.
- Make sure `data-books.json` stays beside `index.html`.
- Open the VS Code folder root so relative file paths work.
